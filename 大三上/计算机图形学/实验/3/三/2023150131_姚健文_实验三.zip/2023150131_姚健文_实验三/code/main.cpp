#include "Angel.h"
#include "TriMesh.h"
#include "Camera.h"

#include <vector>
#include <string>
#include <algorithm>

int WIDTH = 600;
int HEIGHT = 600;

int mainWindow;

struct openGLObject
{
	// 顶点数组对象
	GLuint vao;
	// 顶点缓存对象
	GLuint vbo;

	// 着色器程序
	GLuint program;
	// 着色器文件
	std::string vshader;
	std::string fshader;
	// 着色器变量
	GLuint pLocation;
	GLuint cLocation;
	GLuint nLocation;

	// 投影变换变量
	GLuint modelLocation;
	GLuint viewLocation;
	GLuint projectionLocation;

	// 阴影变量
	GLuint shadowLocation;
	// 环境光反射、漫反射、镜面反射 控制变量
	GLuint ambientOpen;
	GLuint DiffuseOpen;
	GLuint SpecularOpen;
};

openGLObject mesh_object;

Light* light = new Light();

TriMesh* mesh = new TriMesh();

Camera* camera = new Camera();

bool ambientEnabled = true;
bool diffuseEnabled = true;
bool specularEnabled = true;

bool isOrtho = false;

// 全局变量 键盘控制光源移动的参数 光源位置
float move_step_size = 0.2;
glm::vec3 light_pos(2.0, 5.0, 2.0);

void bindObjectAndData(TriMesh* mesh, openGLObject& object, const std::string& vshader, const std::string& fshader)
{

	// 创建顶点数组对象
	glGenVertexArrays(1, &object.vao); // 分配1个顶点数组对象
	glBindVertexArray(object.vao);	   // 绑定顶点数组对象

	// 创建并初始化顶点缓存对象
	glGenBuffers(1, &object.vbo);
	glBindBuffer(GL_ARRAY_BUFFER, object.vbo);
	glBufferData(GL_ARRAY_BUFFER,
		(mesh->getPoints().size() + mesh->getColors().size() + mesh->getNormals().size()) * sizeof(glm::vec3),
		NULL,
		GL_STATIC_DRAW);

	glBufferSubData(GL_ARRAY_BUFFER, 0, mesh->getPoints().size() * sizeof(glm::vec3), &mesh->getPoints()[0]);
	glBufferSubData(GL_ARRAY_BUFFER, mesh->getPoints().size() * sizeof(glm::vec3), mesh->getColors().size() * sizeof(glm::vec3), &mesh->getColors()[0]);

	glBufferSubData(GL_ARRAY_BUFFER, (mesh->getPoints().size() + mesh->getColors().size()) * sizeof(glm::vec3), mesh->getNormals().size() * sizeof(glm::vec3), &mesh->getNormals()[0]);

	object.vshader = vshader;
	object.fshader = fshader;
	object.program = InitShader(object.vshader.c_str(), object.fshader.c_str());

	// 从顶点着色器中初始化顶点的坐标
	object.pLocation = glGetAttribLocation(object.program, "vPosition");
	glEnableVertexAttribArray(object.pLocation);
	glVertexAttribPointer(object.pLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));

	// 从顶点着色器中初始化顶点的颜色
	object.cLocation = glGetAttribLocation(object.program, "vColor");
	glEnableVertexAttribArray(object.cLocation);
	glVertexAttribPointer(object.cLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(mesh->getPoints().size() * sizeof(glm::vec3)));

	// @TODO: Task1 从顶点着色器中初始化顶点的法向量
	object.nLocation = glGetAttribLocation(object.program, "vNormal");
	glEnableVertexAttribArray(object.nLocation);
	glVertexAttribPointer(object.nLocation, 3, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET((mesh->getPoints().size() + mesh->getColors().size()) * sizeof(glm::vec3)));

	// 获得矩阵位置
	object.modelLocation = glGetUniformLocation(object.program, "model");
	object.viewLocation = glGetUniformLocation(object.program, "view");
	object.projectionLocation = glGetUniformLocation(object.program, "projection");

	object.shadowLocation = glGetUniformLocation(object.program, "isShadow");

	object.ambientOpen = glGetUniformLocation(object.program, "ambientOpen");
	object.DiffuseOpen = glGetUniformLocation(object.program, "DiffuseOpen");
	object.SpecularOpen = glGetUniformLocation(object.program, "SpecularOpen");
}

void bindLightAndMaterial(TriMesh* mesh, openGLObject& object, Light* light, Camera* camera)
{

	// 传递相机的位置
	glUniform3fv(glGetUniformLocation(object.program, "eye_position"), 1, &camera->eye[0]);

	// 传递物体的材质
	glm::vec4 meshAmbient = mesh->getAmbient();
	glm::vec4 meshDiffuse = mesh->getDiffuse();
	glm::vec4 meshSpecular = mesh->getSpecular();
	float meshShininess = mesh->getShininess();
	glUniform4fv(glGetUniformLocation(object.program, "material.ambient"), 1, &meshAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.diffuse"), 1, &meshDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "material.specular"), 1, &meshSpecular[0]);
	glUniform1f(glGetUniformLocation(object.program, "material.shininess"), meshShininess);

	// 传递光源信息
	glm::vec4 lightAmbient = light->getAmbient();
	glm::vec4 lightDiffuse = light->getDiffuse();
	glm::vec4 lightSpecular = light->getSpecular();
	glm::vec3 lightPosition = light->getTranslation();

	glUniform4fv(glGetUniformLocation(object.program, "light.ambient"), 1, &lightAmbient[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.diffuse"), 1, &lightDiffuse[0]);
	glUniform4fv(glGetUniformLocation(object.program, "light.specular"), 1, &lightSpecular[0]);
	glUniform3fv(glGetUniformLocation(object.program, "light.position"), 1, &lightPosition[0]);
}

void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	// make sure the viewport matches the new window dimensions; note that width and
	// height will be significantly larger than specified on retina displays.
	glViewport(0, 0, width, height);
}

void init()
{	
	glClearColor(0.5, 0.5, 0.5, 0.0);  // 设置为灰色背景

	std::string vshader, fshader;
	// 读取着色器并使用
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";

	// 设置物体的旋转位移
	mesh->setTranslation(glm::vec3(0.0, 0.0, 0.0));
	mesh->setRotation(glm::vec3(0.0, 0.0, 0.0));
	mesh->setScale(glm::vec3(1.0, 1.0, 1.0));

	mesh->setTranslation(glm::vec3(0.0, 0.65, 0.0));  // 抬高一点使得底部大致在y=0平面上

	// 设置光源位置
	light->setTranslation(light_pos);
	light->setAmbient(glm::vec4(1.0, 1.0, 1.0, 1.0));  // 环境光
	light->setDiffuse(glm::vec4(1.0, 1.0, 1.0, 1.0));  // 漫反射
	light->setSpecular(glm::vec4(1.0, 1.0, 1.0, 1.0)); // 镜面反射

	// 设置材质
	mesh->setAmbient(glm::vec4(0.2, 0.2, 0.2, 1.0));  // 环境光
	mesh->setDiffuse(glm::vec4(0.7, 0.7, 0.7, 1.0));  // 漫反射
	mesh->setSpecular(glm::vec4(0.2, 0.2, 0.2, 1.0)); // 镜面反射
	mesh->setShininess(1.0);						  // 高光系数

	// 将物体的顶点数据传递
	bindObjectAndData(mesh, mesh_object, vshader, fshader);

	ambientEnabled = true;
	diffuseEnabled = true;
	specularEnabled = true;
}

void display()
{
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// 相机矩阵计算
	camera->updateCamera();
	camera->viewMatrix = camera->getViewMatrix();
	camera->projMatrix = camera->getProjectionMatrix(isOrtho);

	glBindVertexArray(mesh_object.vao);

	glUseProgram(mesh_object.program);

	// 物体的变换矩阵
	glm::mat4 modelMatrix = mesh->getModelMatrix();

	// 传递矩阵
	glUniformMatrix4fv(mesh_object.modelLocation, 1, GL_FALSE, &modelMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);
	// 将着色器 isShadow 设置为0，表示正常绘制的颜色，如果是1则表示阴影
	glUniform1i(mesh_object.shadowLocation, 0);


	glUniform1i(mesh_object.ambientOpen, ambientEnabled ? 1 : 0);
	glUniform1i(mesh_object.DiffuseOpen, diffuseEnabled ? 1 : 0);
	glUniform1i(mesh_object.SpecularOpen, specularEnabled ? 1 : 0);

	// 将材质和光源数据传递给着色器
	bindLightAndMaterial(mesh, mesh_object, light, camera);
	// 绘制
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());


	// 绘制阴影
	glm::mat4 shadowMatrix = glm::mat4(0.0f);
	shadowMatrix = light->getShadowProjectionMatrix();

	// 计算阴影的模型变换矩阵。
	glm::mat4 shadowModelMatrix = shadowMatrix * mesh->getModelMatrix();

	// 传递 isShadow 变量。

	// 传递 unifrom 关键字的矩阵数据。
	glUniformMatrix4fv(mesh_object.modelLocation, 1, GL_FALSE, &shadowModelMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.viewLocation, 1, GL_FALSE, &camera->viewMatrix[0][0]);
	glUniformMatrix4fv(mesh_object.projectionLocation, 1, GL_FALSE, &camera->projMatrix[0][0]);

	// 绘制
	glUniform1i(mesh_object.shadowLocation, 1);
	glDrawArrays(GL_TRIANGLES, 0, mesh->getPoints().size());

}

void printHelp()
{
	std::cout << "Keyboard Usage" << std::endl;
	std::cout 
		<< "[Window]" << std::endl
		<< "ESC:		Exit" << std::endl
		<< "h:		Print help message" << std::endl
		<< std::endl
		<< "[Light]" << std::endl
		<< std::endl
		<< "x/X:		Increase/Decrease the x of light_pos" << std::endl
		<< "y/Y:		Increase/Decrease the y of light_pos" << std::endl
		<< "z/Z:		Increase/Decrease the z of light_pos" << std::endl
		<< std::endl
		<< "[Camera]" << std::endl
		<< "SPACE:		Reset camera parameters" << std::endl
		<< "q/Q:		Increase/Decrease the rotate angle" << std::endl
		<< "w/W:		Increase/Decrease the up angle" << std::endl
		<< "e/E:		Increase/Decrease the camera radius" << std::endl
		<< "o:		Use orthographic projection" << std::endl
		<< "p:		Use perspective projection" << std::endl;
}

void mainWindow_key_callback(GLFWwindow* window, int key, int scancode, int action, int mode)
{
	if (key == GLFW_KEY_ESCAPE && action == GLFW_PRESS)
	{
		glfwSetWindowShouldClose(window, GL_TRUE);
	}
	else if (key == GLFW_KEY_H && action == GLFW_PRESS)
	{
		printHelp();
	}

	else if (key == GLFW_KEY_O && action == GLFW_PRESS)  // 切换为正交投影
	{
		isOrtho = true;
		//init();
	}
	else if (key == GLFW_KEY_P && action == GLFW_PRESS)  // 切换为透视投影
	{
		isOrtho = false;
		//init();
	}

	// X、Y、Z移动光源
	else if (key == GLFW_KEY_X && action == GLFW_PRESS && mode == 0x0000)
	{
		light_pos[0] += move_step_size;
		light->setTranslation(light_pos);
	}
	else if (key == GLFW_KEY_X && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		light_pos[0] -= move_step_size;
		light->setTranslation(light_pos);
	}
	else if (key == GLFW_KEY_Y && action == GLFW_PRESS && mode == 0x0000)
	{
		light_pos[1] += move_step_size;
		light->setTranslation(light_pos);

	}
	else if (key == GLFW_KEY_Y && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		light_pos[1] -= move_step_size;
		if (light_pos[1] <= 1.0) {
			light_pos[1] += move_step_size;
		}
		light->setTranslation(light_pos);

	}
	else if (key == GLFW_KEY_Z && action == GLFW_PRESS && mode == 0x0000)
	{
		light_pos[2] += move_step_size;
		light->setTranslation(light_pos);

	}
	else if (key == GLFW_KEY_Z && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		light_pos[2] -= move_step_size;
		light->setTranslation(light_pos);

	}

	else
	{
		camera->keyboard(key, action, mode);
	}
}

// 重新设置窗口
void reshape(GLsizei w, GLsizei h)
{
	glViewport(0, 0, w, h);
}

void cleanData()
{
	mesh->cleanData();

	delete camera;
	camera = NULL;

	// 释放内存
	delete mesh;
	mesh = NULL;

	// 删除绑定的对象
	glDeleteVertexArrays(1, &mesh_object.vao);
	glDeleteBuffers(1, &mesh_object.vbo);
	glDeleteProgram(mesh_object.program);
}

int main(int argc, char** argv)
{
	glfwInit();
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

#ifdef __APPLE__
	glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#endif

	GLFWwindow* mainwindow = glfwCreateWindow(600, 600, "2023150131_姚健文_实验3", NULL, NULL);
	if (mainwindow == NULL)
	{
		std::cout << "Failed to create GLFW window!" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(mainwindow);
	glfwSetFramebufferSizeCallback(mainwindow, framebuffer_size_callback);
	glfwSetKeyCallback(mainwindow, mainWindow_key_callback);
	//glfwSetMouseButtonCallback(mainwindow, mouse_button_callback);
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}
	glEnable(GL_DEPTH_TEST);
	mesh->readOff("./assets/Pikachu.off");
	//mesh->generateCube();
	// Init mesh, shaders, buffer
	init();
	printHelp();
	// bind callbacks
	while (!glfwWindowShouldClose(mainwindow))
	{

		display();
		glfwSwapBuffers(mainwindow);
		glfwPollEvents();
	}
	glfwTerminate();
	return 0;
}
