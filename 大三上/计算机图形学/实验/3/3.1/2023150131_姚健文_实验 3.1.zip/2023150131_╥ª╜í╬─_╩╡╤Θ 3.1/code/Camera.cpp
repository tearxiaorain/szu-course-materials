﻿#include "Camera.h"

Camera::Camera() { updateCamera(); };
Camera::~Camera() {};


glm::mat4 Camera::lookAt(const glm::vec4& eye, const glm::vec4& at, const glm::vec4& up)
{	
	// @TODO: Task1:请按照实验课内容补全相机观察矩阵的计算
	glm::vec3 e = glm::vec3(eye);
	glm::vec3 a = glm::vec3(at);
	glm::vec3 up3 = glm::vec3(up);

	glm::vec3 VPN = e - a;
	glm::vec3 n = glm::normalize(VPN);
	glm::vec3 u = glm::normalize(glm::cross(up3, n));
	glm::vec3 v = glm::normalize(glm::cross(n, u));

	glm::mat4 c = glm::mat4(1.0f);
	c[0][0] = u.x; c[1][0] = u.y; c[2][0] = u.z; c[3][0] = -e.x * u.x - e.y * u.y - e.z * u.z;
	c[0][1] = v.x; c[1][1] = v.y; c[2][1] = v.z; c[3][1] = -e.x * v.x - e.y * v.y - e.z * v.z;
	c[0][2] = n.x; c[1][2] = n.y; c[2][2] = n.z; c[3][2] = -e.x * n.x - e.y * n.y - e.z * n.z;

	return c;
			
}


glm::mat4 Camera::ortho(const GLfloat left, const GLfloat right,
	const GLfloat bottom, const GLfloat top,
	const GLfloat zNear, const GLfloat zFar)
{
	// @TODO: Task2:请按照实验课内容补全正交投影矩阵的计算
	glm::mat4 c = glm::mat4(1.0f);
	c[0][0] = 2 / (right - left);  c[3][0] = -(right + left) / (right - left);
	c[1][1] = 2 / (top - bottom);  c[3][1] = -(top + bottom) / (top - bottom);
	c[2][2] = -2 / (zFar - zNear);  c[3][2] = -(zFar + zNear) / (zFar - zNear);

	return c;
}


glm::mat4 Camera::perspective(const GLfloat fov, const GLfloat aspect,
	const GLfloat zNear, const GLfloat zFar)
{
	// @TODO: Task3:请按照实验课内容补全透视投影矩阵的计算
	glm::mat4 c = glm::mat4(1.0f);
	GLfloat top = zNear * tan(fov / 2);
	GLfloat right = top * aspect;

	c[0][0] = zNear / right; 
	c[1][1] = zNear / top; 
	c[2][2] = -(zFar + zNear) / (zFar - zNear); c[3][2] = -(2 * zFar * zNear) / (zFar - zNear);
	c[2][3] = -1; c[3][3] = 0;

	return c;
}


glm::mat4 Camera::frustum(const GLfloat left, const GLfloat right,
	const GLfloat bottom, const GLfloat top,
	const GLfloat zNear, const GLfloat zFar)
{
	// 任意视锥体矩阵
	glm::mat4 c = glm::mat4(1.0f);
	c[0][0] = 2.0 * zNear / (right - left);
	c[0][2] = (right + left) / (right - left);
	c[1][1] = 2.0 * zNear / (top - bottom);
	c[1][2] = (top + bottom) / (top - bottom);
	c[2][2] = -(zFar + zNear) / (zFar - zNear);
	c[2][3] = -2.0 * zFar * zNear / (zFar - zNear);
	c[3][2] = -1.0;
	c[3][3] = 0.0;
	c = glm::transpose(c);
	return c;
}


void Camera::updateCamera()
{
	// @TODO: Task1 计算相机位置(eyex, eyey, eyez)
	float ra = glm::radians(rotateAngle);
	float ua = glm::radians(upAngle);

	float eyex = radius * cos(ua) * sin(ra);	// 根据rotateAngle和upAngle设置x
	float eyey = radius * sin(ua);			    // 根据upAngle设置y
	float eyez = radius * cos(ua) * cos(ra);	// 根据rotateAngle和upAngle设置z
	
	eye = glm::vec4(eyex, eyey, eyez, 1.0);
	at = glm::vec4(0.0, 0.0, 0.0, 1.0);
	up = glm::vec4(0.0, 1.0, 0.0, 0.0);
	if (upAngle > 90){
		up.y = -1;
	}
	else if (upAngle < -90){
		up.y = -1;
	}
}


void Camera::keyboard(int key, int action, int mode)
{

	// 键盘事件处理
	if (key == GLFW_KEY_X && action == GLFW_PRESS && mode == 0x0000)
	{
		rotateAngle += 5.0;
	}
	else if(key == GLFW_KEY_X && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		rotateAngle -= 5.0;
	}
	else if(key == GLFW_KEY_Y && action == GLFW_PRESS && mode == 0x0000)
	{
		upAngle += 5.0;
		if (upAngle > 180)
			upAngle = 180;
	}
	else if(key == GLFW_KEY_Y && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		upAngle -= 5.0;
		if (upAngle < -180)
			upAngle = -180;
	}
	else if(key == GLFW_KEY_R && action == GLFW_PRESS && mode == 0x0000)
	{
		radius += 0.1;
	}
	else if(key == GLFW_KEY_R && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		radius -= 0.1;
	}
	else if(key == GLFW_KEY_F && action == GLFW_PRESS && mode == 0x0000)
	{
		fov += 5.0;
	}
	else if(key == GLFW_KEY_F && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		fov -= 5.0;
	}
	else if(key == GLFW_KEY_A && action == GLFW_PRESS && mode == 0x0000)
	{
		aspect += 0.1;
	}
	else if(key == GLFW_KEY_A && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		aspect -= 0.1;
	}
	else if(key == GLFW_KEY_S && action == GLFW_PRESS && mode == 0x0000)
	{
		scale += 0.1;
	}
	else if(key == GLFW_KEY_S && action == GLFW_PRESS && mode == GLFW_MOD_SHIFT)
	{
		scale -= 0.1;
	}
	else if(key == GLFW_KEY_SPACE && action == GLFW_PRESS && mode == 0x0000)
	{
		radius = 4.0;
		rotateAngle = 0.0;
		upAngle = 0.0;
		fov = 45.0;
		aspect = 1.0;
		scale = 1.5;
	}
}
