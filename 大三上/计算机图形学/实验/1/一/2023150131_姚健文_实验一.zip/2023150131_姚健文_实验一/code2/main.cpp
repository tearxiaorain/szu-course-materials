#include "Angel.h"
#include <string>

const glm::vec3 WHITE(1.0, 1.0, 1.0);
const glm::vec3 BLACK(0.0, 0.0, 0.0);
const glm::vec3 RED(1.0, 0.0, 0.0);
const glm::vec3 GREEN(0.0, 1.0, 0.0);
const glm::vec3 BLUE(0.0, 0.0, 1.0); 
const int CIRCLE_NUM_POINTS = 100;
const int ELLIPSE_NUM_POINTS = 100;
const int TRIANGLE_NUM_POINTS  = 3;
const int SQUARE_NUM  = 6;
const int SQUARE_NUM_POINTS  = 4 * SQUARE_NUM;

// 每当窗口改变大小，GLFW会调用这个函数并填充相应的参数
void framebuffer_size_callback(GLFWwindow* window, int width, int height)
{
	glViewport(0, 0, width, height);
}

// 根据角度生成颜色
float generateAngleColor(double angle)
{
	return 1.0 / (2 * M_PI) * angle;
}

// 获得三角形的每个角度
double getTriangleAngle(int point)
{
	return 2 * M_PI / 3 * point;
}

// 获得三角形的每个角度 (等腰)  // point取0，1，2，angle为底角
double getTriangleAngle(int point, int angle)
{
	return M_PI / 360 * angle * 4 * (point - 1);
}

// 获得正方形的每个角度
double getSquareAngle(int point)
{
	return M_PI / 4 + (M_PI / 2 * point);
}

// 计算椭圆/圆上的点
glm::vec2 getEllipseVertex(glm::vec2 center, double scale, double verticalScale, double angle)
{
	glm::vec2 vertex(sin(angle), cos(angle));
	vertex *= scale;
	vertex.y *= verticalScale;
	vertex += center;
	return vertex;
}

// 获得椭圆/圆的每个顶点
void generateEllipsePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex, int numPoints,
	double center_x, double center_y, double scale, double verticalScale, int c) // c用于判断生成黑白色
{
	glm::vec2 center(center_x, center_y);
	double angleIncrement = (2 * M_PI) / numPoints;
	double currentAngle = M_PI / 2;

	for (int i = startVertexIndex; i < startVertexIndex + numPoints; ++i) {
		vertices[i] = getEllipseVertex(center, scale, verticalScale, currentAngle);
		if (c == 0) {
			colors[i] = WHITE;
		} else {
			colors[i] = BLACK;
		}
		currentAngle += angleIncrement;
	}
}

// 获得三角形的每个顶点
void generateTrianglePoints(glm::vec2 vertices[], glm::vec3 colors[], int startVertexIndex,
	double center_x, double center_y, double scale_s, int angle_bottom, int delta, int c)  // c用于判断生成黑白色
{
	glm::vec2 center(center_x, center_y);
	glm::vec2 scale(scale_s, scale_s);

	for (int i = 0; i < 3; ++i) {
		double currentAngle = getTriangleAngle(i, angle_bottom) + 2 * M_PI / 360 * delta;
		vertices[startVertexIndex + i] = glm::vec2(sin(currentAngle), cos(currentAngle)) * scale + center;
	}

	if (c == 0) {
		colors[startVertexIndex] = colors[startVertexIndex + 1] = colors[startVertexIndex + 2] = WHITE;
	} else {
		colors[startVertexIndex] = colors[startVertexIndex + 1] = colors[startVertexIndex + 2] = BLACK;
	}
}

// 获得正方形的每个顶点
void generateSquarePoints(glm::vec2 vertices[], glm::vec3 colors[], int squareNumber, int startVertexIndex)
{
	glm::vec2 scale(0.90, 0.90);
	double scaleDecrease = 0.15;
	glm::vec2 center(0.0, -0.25);
	int vertexIndex = startVertexIndex;

	for (int i = 0; i < squareNumber; ++i) {
		glm::vec3 currentColor;
		currentColor = (i % 2) ? BLACK : WHITE;
		for (int j = 0; j < 4; ++j) {
			double currentAngle = getSquareAngle(j);
			vertices[vertexIndex] = glm::vec2(sin(currentAngle), cos(currentAngle)) * scale + center;
			colors[vertexIndex] = currentColor;
			vertexIndex++;
		}
		scale -= scaleDecrease;
	}
}


GLuint vao[10], program;
void init()
{
	// 定义三角形的点
	glm::vec2 triangle_vertices[5][TRIANGLE_NUM_POINTS];
	glm::vec3 triangle_colors[5][TRIANGLE_NUM_POINTS];
	double triangle_info[5][6] = {
		-0.3, 0.25, 0.3,  50,  -45, 0,
		-0.6, 0.15, 0.3,  30,  90,  1,
		0.3,  0.25, 0.3,  50,  45,  0,
		0.6,  0.15, 0.3,  30,  -90, 1,
		0,    -0.3, 0.07, 70, 180, 1
	}; // 中心坐标x,y, 缩放比例, 等腰的底角, 旋转角度, 黑白色标志

	// 定义椭圆上的点和颜色
	glm::vec2 ellipse_vertices[5][ELLIPSE_NUM_POINTS];
	glm::vec3 ellipse_colors[5][ELLIPSE_NUM_POINTS];
	double ellipse_info[5][5] = {
		0,     0, 0.5,  0.9, 0,
		-0.25, 0, 0.2,  1.3, 1,
		-0.23, 0, 0.13, 1.3, 0,
		0.25,  0, 0.2,  1.3, 1,
		0.23,  0, 0.13, 1.3, 0
	}; // 中心坐标x,y, 缩放比例, 垂直缩放比例, 黑白色标志

	// 调用生成形状顶点位置的函数
	for (int i = 0; i < 5; i++)
	{
		double center_x, center_y, scale_s, angle_b, del, c_flag;
		center_x = triangle_info[i][0];
		center_y = triangle_info[i][1];
		scale_s = triangle_info[i][2];
		angle_b = triangle_info[i][3];
		del = triangle_info[i][4];
		c_flag = triangle_info[i][5];
		generateTrianglePoints(triangle_vertices[i], triangle_colors[i], 0, center_x, center_y, scale_s, angle_b, del, c_flag);
	}
	for (int i = 0; i < 5; i++)
	{
		double center_x, center_y, scale_s, scale_y, c_flag;
		center_x = ellipse_info[i][0];
		center_y = ellipse_info[i][1];
		scale_s = ellipse_info[i][2];
		scale_y = ellipse_info[i][3];
		c_flag = ellipse_info[i][4];
		generateEllipsePoints(ellipse_vertices[i], ellipse_colors[i], 0, ELLIPSE_NUM_POINTS, center_x, center_y, scale_s, scale_y, c_flag);
	}

	// 读取着色器并使用
	std::string vshader, fshader;
	vshader = "shaders/vshader.glsl";
	fshader = "shaders/fshader.glsl";
	program = InitShader(vshader.c_str(), fshader.c_str());
	glUseProgram(program);

	// 创建顶点缓存对象，vbo[2]是因为我们将要使用两个缓存对象
	GLuint vbo[2];

	/*
	* 初始化三角形的数据
	*/

	for (int i = 0; i < 5; i++)
	{
		glGenVertexArrays(1, &vao[i]);
		glBindVertexArray(vao[i]);

		glGenBuffers(1, &vbo[0]);
		glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(triangle_vertices[i]), triangle_vertices[i], GL_STATIC_DRAW);
		GLuint location = glGetAttribLocation(program, "vPosition");
		glEnableVertexAttribArray(location);
		glVertexAttribPointer(
			location,
			2,
			GL_FLOAT,
			GL_FALSE,
			sizeof(glm::vec2),
			BUFFER_OFFSET(0));

		glGenBuffers(1, &vbo[1]);
		glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(triangle_colors[i]), triangle_colors[i], GL_STATIC_DRAW);
		GLuint cLocation = glGetAttribLocation(program, "vColor");
		glEnableVertexAttribArray(cLocation);
		glVertexAttribPointer(
			cLocation,
			3,
			GL_FLOAT,
			GL_FALSE,
			sizeof(glm::vec3),
			BUFFER_OFFSET(0));
	}

	/*
	* 初始化椭圆的数据
	*/
	
	for (int i = 0; i < 5; i++)
	{
		glGenVertexArrays(1, &vao[i+5]);
		glBindVertexArray(vao[i+5]);

		glGenBuffers(1, &vbo[0]);
		glBindBuffer(GL_ARRAY_BUFFER, vbo[0]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(ellipse_vertices[i]), ellipse_vertices[i], GL_STATIC_DRAW);
		GLuint location = glGetAttribLocation(program, "vPosition");
		glEnableVertexAttribArray(location);
		glVertexAttribPointer(
			location,
			2,
			GL_FLOAT,
			GL_FALSE,
			sizeof(glm::vec2),
			BUFFER_OFFSET(0));

		glGenBuffers(1, &vbo[1]);
		glBindBuffer(GL_ARRAY_BUFFER, vbo[1]);
		glBufferData(GL_ARRAY_BUFFER, sizeof(ellipse_colors[i]), ellipse_colors[i], GL_STATIC_DRAW);
		GLuint cLocation = glGetAttribLocation(program, "vColor");
		glEnableVertexAttribArray(cLocation);
		glVertexAttribPointer(
			cLocation,
			3,
			GL_FLOAT,
			GL_FALSE,
			sizeof(glm::vec3),
			BUFFER_OFFSET(0));
	}

	glClearColor(0.0, 0.0, 0.0, 1.0);
}

void display(void)
{
	glClear(GL_COLOR_BUFFER_BIT);
	glUseProgram(program);
	
	/*glBindVertexArray(vao[1]);
	for (int i = 0; i  < SQUARE_NUM; ++i) {
		glDrawArrays(GL_TRIANGLE_FAN, (i  * 4), 4);
	}*/

	// 绘制三角形
	for (int i = 0; i < 4; i++)
	{
		glBindVertexArray(vao[i]);
		glDrawArrays(GL_TRIANGLES, 0, TRIANGLE_NUM_POINTS);
	}

	// 绘制椭圆
	for (int i = 5; i < 10; i++)
	{
		glBindVertexArray(vao[i]);
		glDrawArrays(GL_TRIANGLE_FAN, 0, ELLIPSE_NUM_POINTS);
	}

	glBindVertexArray(vao[4]);
	glDrawArrays(GL_TRIANGLES, 0, TRIANGLE_NUM_POINTS);

	glFlush();
}

int main(int argc, char **argv)
{
	// 初始化GLFW库
	glfwInit();

	// 配置GLFW
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
	glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);

	#ifdef __APPLE__
		glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
	#endif

	// 配置窗口属性
	GLFWwindow* window = glfwCreateWindow(512, 512, "2023150131_姚健文_实验一", NULL, NULL);
	if (window == NULL)
	{
		std::cout << "Failed to create GLFW window" << std::endl;
		glfwTerminate();
		return -1;
	}
	glfwMakeContextCurrent(window);
	glfwSetFramebufferSizeCallback(window, framebuffer_size_callback);

	// 调用任何OpenGL的函数之前初始化GLAD
	if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress))
	{
		std::cout << "Failed to initialize GLAD" << std::endl;
		return -1;
	}

	init();

	std::cout << "OpenGL Vendor: " << glGetString(GL_VENDOR) << std::endl;
	std::cout << "OpenGL Renderer: " << glGetString(GL_RENDERER) << std::endl;
	std::cout << "OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
	std::cout << "Supported GLSL version is: " << glGetString(GL_SHADING_LANGUAGE_VERSION) << std::endl;
	
	
	while (!glfwWindowShouldClose(window))
	{	
		display();
		// 交换颜色缓冲 以及 检查有没有触发什么事件（比如键盘输入、鼠标移动等）
		glfwSwapBuffers(window);
		glfwPollEvents();
	}
	return 0;
}
